package application.components;

import application.structures.Vector;
import application.utils.CalculationUtils;

import java.awt.*;
import java.util.ArrayList;

/**
 * Name:        Jinesh Patel
 * Date:        2016-01-01
 * File:        ui.components.JVectorView.java
 * Description:
 */
public class JVectorView extends JMapView {
    private ArrayList<Vector> vectors;

    private int arrow = 20;

    public int getArrow() {
        return arrow;
    }

    public void setArrow(int arrow) {
        this.arrow = arrow;

        this.repaint();
    }

    @Override
    protected void paintComponent(Graphics2D g) {
        super.paintComponent(g);

        g.setColor(Color.BLACK);
        g.drawOval(-10, -10, 20, 20);
        g.fillOval(-1, -1, 2, 2);

        if (vectors != null && vectors.size() > 0) {
            for (application.structures.Vector vector : vectors)
                this.drawVector(g, vector);

            g.drawLine(0, 0, vectors.get(vectors.size() - 1).getEndX(), vectors.get(vectors.size() - 1).getEndY());
        }
    }

    @SuppressWarnings("SameParameterValue")
    private void reconnectVectors(int index) {
        if (vectors.size() >= 1) {
            vectors.get(0).setStartX(0);
            vectors.get(0).setStartY(0);
        }

        for (int i = index; i < vectors.size(); i++) {
            vectors.get(i).setStartX(vectors.get(i - 1).getEndX());
            vectors.get(i).setStartY(vectors.get(i - 1).getEndY());
        }

        this.repaint();
    }

    private void drawVector(Graphics2D g, Vector vector) {
        g.setColor(vector.getColor());

        BasicStroke subtract = new BasicStroke(1.0f,
                BasicStroke.CAP_BUTT,
                BasicStroke.JOIN_MITER,
                10.0f,
                new float[] {10.0f},
                0.0f);
        BasicStroke add = new BasicStroke(
                1.0f,
                BasicStroke.CAP_BUTT,
                BasicStroke.JOIN_MITER);

        g.setStroke(vector.getMode() == Vector.VectorMode.SUBTRACT
                ? subtract
                : add);

        g.drawLine(vector.getStartX(), vector.getStartY(), vector.getEndX(), vector.getEndY());

        this.drawArrowTip(g, vector.getEndX(), vector.getEndY(), vector.getMode() == Vector.VectorMode.SUBTRACT
                ? vector.getAngle() - 180
                : vector.getAngle());
    }

    private void drawArrowTip(Graphics2D g, int x, int y, double angle) {
        g.rotate(Math.toRadians(angle), x, y);

        Polygon p = new Polygon();

        int leftx = ((int) (x + CalculationUtils.getXComponent(arrow, 145)));
        int lefty = ((int) (y + CalculationUtils.getYComponent(arrow, 145)));

        int rightx = ((int) (x + CalculationUtils.getXComponent(arrow, 215)));
        int righty = ((int) (y + CalculationUtils.getYComponent(arrow, 215)));

        p.addPoint(x + 2, y);
        p.addPoint(leftx, lefty);
        p.addPoint(rightx, righty);

        g.fillPolygon(p);

        g.rotate(Math.toRadians(-angle), x, y);
    }

    public ArrayList<Vector> getItems() {
        return vectors;
    }

    public void setItems(ArrayList<Vector> items) {
        this.vectors = items;

        this.reconnectVectors(1);
        this.repaint();
    }

    private int getMaxX() {
        int max = vectors.get(0).getEndX();

        for (Vector v : vectors)
            if (v.getEndX() > max || v.getStartX() > max)
                max = Math.max(v.getEndX(), v.getStartX());

        return max;
    }

    private int getMaxY() {
        int max = vectors.get(0).getEndY();

        for (Vector v : vectors)
            if (v.getEndY() > max || v.getStartY() > max)
                max = Math.max(v.getEndY(), v.getStartY());

        return max;
    }

    private int getMinX() {
        int min = vectors.get(0).getEndX();

        for (Vector v : vectors)
            if (v.getEndX() < min || v.getStartX() < min)
                min = Math.min(v.getEndX(), v.getStartX());

        return min;
    }

    private int getMinY() {
        int min = vectors.get(0).getEndY();

        for (Vector v : vectors)
            if (v.getEndY() < min || v.getStartY() < min)
                min = Math.min(v.getEndY(), v.getStartY());

        return min;
    }

    public void zoom() {
        double xrange = getMaxX() - getMinX();
        double yrange = getMaxY() - getMinY();

        double tx = getMinX();
        double ty = getMinY();

        super.zoom(xrange, yrange, tx, ty);
    }
}
