package application.components;

import application.structures.Force;
import application.utils.CalculationUtils;

import java.awt.*;
import java.util.ArrayList;

/**
 * Name:        Hassaan Zaki
 * Date:        2016-01-05
 * File:        components.JForceView.java
 * Description: View element for the Forces
 */
public class JForceView extends JMapView {
    //Array to store all the forcess
    private ArrayList<Force> forces;

    /**
     * Setter Method for the forces
     * @param forces The array for the forces
     */
    public void setForces(ArrayList<Force> forces) {
        this.forces = forces;

        this.repaint();
    }

    //region Arrow
    //Size of the arrow
    private int arrow = 10;

    /**
     * Getter method for the size arrow
     * @return The size of the arrow
     */
    public int getArrow() {
        return arrow;
    }

    /**
     * Setter method for the size arrow
     * @param arrow Size of the arrow
     */
    public void setArrow(int arrow) {
        this.arrow = arrow;

        this.repaint();
    }

    /**
     * Draws the tip of the arrow at the end of the force
     * @param g graphics force
     * @param x x location for the arrow
     * @param y y location for the arrow
     * @param angle the angle at which it must be placed
     */
    private void drawArrowTip(Graphics2D g, int x, int y, double angle) {
        g.rotate(Math.toRadians(angle), x, y);

        Polygon p = new Polygon();

        p.addPoint(x + 2, y);
        p.addPoint(((int) (x + CalculationUtils.getXComponent(arrow, 145))),
                ((int) (y + CalculationUtils.getYComponent(arrow, 145))));
        p.addPoint(((int) (x + CalculationUtils.getXComponent(arrow, 215))),
                ((int) (y + CalculationUtils.getYComponent(arrow, 215))));

        g.fillPolygon(p);

        g.rotate(Math.toRadians(-angle), x, y);
    }
    //endregion

    /**
     * Default constructor
     */
    public JForceView() {
        this.setPreferredSize(new Dimension(500, 500));
    }

    //region Force

    /**
     * Draws the all the arrow and forces on the screen
     * @param g The Graphics component for the program
     */
    @Override
    protected void paintComponent(Graphics2D g) {
        super.paintComponent(g);

        g.setColor(Color.BLACK);
        g.fillOval(-4, -4, 7, 7);

        if (forces != null) {
            for (Force force : forces)
                drawForce(g, force);

            if (forces.size()>1){
                g.drawLine(0, 0, CalculationUtils.netForceX(forces), CalculationUtils.netForceY(forces));
                int angle = CalculationUtils.netForceAngle(forces);
                drawArrowTip(g, CalculationUtils.netForceX(forces), CalculationUtils.netForceY(forces),angle);
            }
        }
    }

    /**
     * Draws the force vector and put the arrow tip at the end
     * @param g The graphics element for the force
     * @param force The force object
     */
    private void drawForce(Graphics2D g, Force force) {
        g.setColor(force.getColor());

        g.drawLine(0, 0, force.getEndX(), force.getEndY());

        drawArrowTip(g, force.getEndX(), force.getEndY(), force.getAngle());
    }

    //endregion

    //region Zoom
    private int getMaxX() {
        int max = forces.get(0).getEndX();

        for (Force f : forces)
            if (f.getEndX() > max || f.getStartX() > max)
                max = Math.max(f.getEndX(), f.getStartX());

        return max;
    }

    private int getMaxY() {
        int max = forces.get(0).getEndY();

        for (Force f: forces)
            if (f.getEndY() > max || f.getStartY() > max)
                max = Math.max(f.getEndY(), f.getStartY());

        return max;
    }

    private int getMinX() {
        int min = forces.get(0).getEndX();

        for (Force f : forces)
            if (f.getEndX() < min || f.getStartX() < min)
                min = Math.min(f.getEndX(), f.getStartX());

        return min;
    }

    private int getMinY() {
        int min = forces.get(0).getEndY();

        for (Force f: forces)
            if (f.getEndY() < min || f.getStartY() < min)
                min = Math.min(f.getEndY(), f.getStartY());

        return min;
    }

    public void zoom() {
        double xrange = getMaxX() - getMinX() + 50;
        double yrange = getMaxY() - getMinY() + 50 + CalculationUtils.netForceY(forces);

        double tx = getMinX() - 125;
        double ty = getMinY() - 50;

        super.zoom(xrange, yrange, tx, ty);
    }
    //endregion
}