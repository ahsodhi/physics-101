package application.structures;

import application.utils.CalculationUtils;

import java.awt.*;

public class Vector implements Cloneable {
    public enum VectorMode {
        ADD,
        SUBTRACT
    }

    private VectorMode mode;

    private int startX;
    private int startY;

    private String name;
    private Color color;

    private double magnitude;
    private double angle;

    public int getStartX() {
        return startX;
    }

    public void setStartX(int startX) {
        this.startX = startX;
    }

    public int getStartY() {
        return startY;
    }

    public void setStartY(int startY) {
        this.startY = startY;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public VectorMode getMode() {
        return mode;
    }

    public void setMode(VectorMode mode) {
        this.mode = mode;
    }

    public double getAngle() {
        return angle;
    }

    public void setAngle(double angle) {
        this.angle = angle % 360;
    }

    public double getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(double magnitude) {
        if (magnitude > 0)
            this.magnitude = magnitude;
    }

    public int getEndY() {
        return ((int) (this.startY + CalculationUtils.getYComponent(
                this.mode == VectorMode.SUBTRACT
                        ? -this.magnitude
                        : this.magnitude, this.angle)));
    }

    public int getEndX() {
        return ((int) (this.startX + CalculationUtils.getXComponent(
                this.mode == VectorMode.SUBTRACT
                        ? -this.magnitude
                        : this.magnitude, this.angle)));
    }

    public Vector(String name, int startX, int startY, double magnitude, double angle, Color color, VectorMode mode) {
        this.setMode(mode);
        this.setStartX(startX);
        this.setStartY(startY);
        this.setName(name);
        this.setColor(color);
        this.setMagnitude(magnitude);
        this.setAngle(angle);
    }

    @Override
    public Vector clone() {
        try {
            return ((Vector) super.clone());
        } catch (CloneNotSupportedException e) {
            return new Vector(
                    this.getName(),
                    this.getStartX(),
                    this.getStartY(),
                    this.getMagnitude(),
                    this.getAngle(),
                    this.getColor(),
                    this.getMode());
        }
    }
}
