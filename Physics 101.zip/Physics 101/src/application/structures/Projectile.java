package application.structures;

/**
 * Created by:  Jinesh Patel
 * Date:        2016-01-19
 * File:        ${FILE_NAME}
 * Description:
 */
public class Projectile implements Cloneable {
    
}
