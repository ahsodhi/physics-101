package application.structures;

import application.utils.CalculationUtils;

import java.awt.*;

/**
 * Created by:  Hassaan Zaki
 * Date:        2016-01-05
 * File:        application.structures.Force.java
 * Description:
 */

public class Force implements Cloneable {

    //region Variables
    private String name;
    private Color color;

    private double magnitude;
    private double angle;
    //endregion

    //region Getters and Setters

    /**
     * Getter for force name
     * @return force name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for force name
     * @param name force name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for force colour
     * @return force colour
     */
    public Color getColor() {
        return color;
    }

    /**
     * Setter for force colour
     * @param color force colour
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Getter for force StartX
     * @return force StartX
     */
    public int getStartX (){
        return 0;
    }

    /**
     * Getter for force StartY
     * @return Force StartY
     */
    public int getStartY (){
        return 0;
    }

    /**
     * Getter for force EndY
     * @return force EndY
     */
    public int getEndY() {
        return ((int) (CalculationUtils.getYComponent(this.magnitude, this.angle)));
    }

    /**
     * Getter for force endsX
     * @return force Endx
     */
    public int getEndX() {
        return ((int) (CalculationUtils.getXComponent(this.magnitude, this.angle)));
    }

    /**
     * Getter for force magnitude
     * @return force Magnitude
     */
    public double getMagnitude() {
        return magnitude;
    }

    /**
     * Setter for force Magnitude
     * @param magnitude force Magnitude
     */
    public void setMagnitude(double magnitude) {
        this.magnitude = magnitude;
    }

    /**
     * Getter for force angle
     * @return force angle
     */
    public double getAngle() {
        return angle;
    }

    /**
     * Setter for force angle
     * @param angle force angle
     */
    public void setAngle(double angle) {
        this.angle = angle;
    }

    //endregion

    /**
     * Force Object
     * @param name name of the force
     * @param magnitude size of the force
     * @param angle angle at which is the force is at
     * @param color colour of the of force
     */
    public Force(String name, double magnitude, double angle, Color color) {
        this.name = name;
        this.color = color;
        this.magnitude = magnitude;
        this.angle = angle;
    }

    /**
     * Clone method for the forces
     * @return force
     */
    @Override
    public Force clone() {
        try {
            return ((Force) super.clone());
        } catch (CloneNotSupportedException e) {
            return new Force(
                    this.getName(),
                    this.getMagnitude(),
                    this.getAngle(),
                    this.getColor());
        }
    }
}
