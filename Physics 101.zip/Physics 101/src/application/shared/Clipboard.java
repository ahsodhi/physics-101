package application.shared;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by:  Jinesh Patel
 * Date:        2016-01-16
 * File:        ${FILE_NAME}
 * Description:
 */
public class Clipboard {
    private static Object[] data;

    public static Object[] getData() {
        return data;
    }

    public static void setData(Object[] data) {
        Clipboard.data = data;
    }

    public static Object clone(Object item) {
        try {
            return item.getClass().getMethod("clone").invoke(item);
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            e.printStackTrace();
        }

        return null;
    }
}
