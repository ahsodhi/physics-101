package application.content;

//region Imports
import application.components.JForceView;
import application.controllers.ForcesListController;
import application.models.ForceModel;
import application.structures.Force;

import static application.shared.Assets.*;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.util.ArrayList;
//endregion

/**
 * Name:        Hassaan Zaki
 * Date:        2016-01-05
 * File:        content.ForceUI.java
 * Description: UI for the program
 */

/**
 * Created by:  Hassaan Zaki
 * Date:        2016-01-11
 * File:        ${FILE_NAME}
 * Description: The View for the Force Unit
 */
public class ForceUI extends MainFrameUI {
    private JList<String> forceList;
    private JForceView forceView;

    private ForcesListController ctrlList;

    /**
     * Overridden method from the superclass to setup the menu
     * of the user interface containing all the actions that
     * are performable in the problem set.
     */
    @Override
    protected void setupMenu() {
        //region JMenu
        JMenu jmFile = createJMenu("File", 'F');
        JMenu jmEdit = createJMenu("Edit", 'E');
        JMenu jmSimulate = createJMenu("Simulate", 'S');
        JMenu jmHelp = createJMenu("Help", 'H');

        JMenuItem jmiNew = createJMenuItem("New", 'N', icoNew, ksNew);
        JMenuItem jmiOpen = createJMenuItem("Open", 'O', icoOpen, ksOpen);
        JMenuItem jmiSave = createJMenuItem("Save", 'S', icoSave, ksSave);
        JMenuItem jmiSaveAs = createJMenuItem("Save As", 'v', null, ksSaveAs);
        JMenuItem jmiPrint = createJMenuItem("Print", 'P', icoPrint, ksPrint);
        JMenuItem jmiPrintPreview = createJMenuItem("Page Setup", 'g', icoPrintPreview, ksPrintPreview);
        JMenuItem jmiExit = createJMenuItem("Exit", 'x', null, null);

        JMenuItem jmiUndo = createJMenuItem("Undo", 'U', icoUndo, ksUndo);
        JMenuItem jmiRedo = createJMenuItem("Redo", 'R', icoRedo, ksRedo);
        JMenuItem jmiCut = createJMenuItem("Cut", 'u', icoCut, ksCut);
        JMenuItem jmiCopy = createJMenuItem("Copy", 'C', icoCopy, ksCopy);
        JMenuItem jmiPaste = createJMenuItem("Paste", 'P', icoPaste, ksPaste);

        JMenuItem jmiAttach = createJMenuItem("Attach", 'A', icoAttach, ksAttach);
        JMenuItem jmiDelete = createJMenuItem("Delete", 'D', icoDelete, ksDelete);
        JMenuItem jmiEdit = createJMenuItem("Edit", 'E', icoEdit, ksEdit);
        JMenuItem jmiMoveUp = createJMenuItem("Move Up", 'U', icoUp, ksUp);
        JMenuItem jmiMoveDown = createJMenuItem("Move Down", 'D', icoDown, ksDown);
        JMenuItem jmiResultant = createJMenuItem("Resultant", 'e', icoResultant, ksResultant);
        JMenuItem jmiEnergy = createJMenuItem("Energy", 'e', icoEnergy, ksEnergy);

        jmFile.add(jmiNew);
        jmFile.addSeparator();
        jmFile.add(jmiOpen);
        jmFile.addSeparator();
        jmFile.add(jmiSave);
        jmFile.add(jmiSaveAs);
        jmFile.addSeparator();
        jmFile.add(jmiPrint);
        jmFile.add(jmiPrintPreview);
        jmFile.addSeparator();
        jmFile.add(jmiExit);

        jmEdit.add(jmiUndo);
        jmEdit.add(jmiRedo);
        jmEdit.addSeparator();
        jmEdit.add(jmiCut);
        jmEdit.add(jmiCopy);
        jmEdit.add(jmiPaste);

        jmSimulate.add(jmiAttach);
        jmSimulate.add(jmiDelete);
        jmSimulate.add(jmiEdit);
        jmSimulate.add(jmiMoveUp);
        jmSimulate.add(jmiMoveDown);
        jmSimulate.addSeparator();
        jmSimulate.add(jmiResultant);
        jmSimulate.add(jmiEnergy);

        jmiNew.addActionListener(ctrlList);
        jmiOpen.addActionListener(ctrlList);
        jmiSave.addActionListener(ctrlList);
        jmiSaveAs.addActionListener(ctrlList);
        jmiPrint.addActionListener(ctrlList);
        jmiPrintPreview.addActionListener(ctrlList);
        jmiExit.addActionListener(ctrlList);
        jmiUndo.addActionListener(ctrlList);
        jmiRedo.addActionListener(ctrlList);
        jmiCut.addActionListener(ctrlList);
        jmiCopy.addActionListener(ctrlList);
        jmiPaste.addActionListener(ctrlList);
        jmiAttach.addActionListener(ctrlList);
        jmiDelete.addActionListener(ctrlList);
        jmiEdit.addActionListener(ctrlList);
        jmiMoveUp.addActionListener(ctrlList);
        jmiMoveDown.addActionListener(ctrlList);
        jmiResultant.addActionListener(ctrlList);
        jmiEnergy.addActionListener(ctrlList);

        jmiNew.setActionCommand(cmdNew);
        jmiOpen.setActionCommand(cmdOpen);
        jmiSave.setActionCommand(cmdSave);
        jmiSaveAs.setActionCommand(cmdSaveAs);
        jmiPrint.setActionCommand(cmdPrint);
        jmiPrintPreview.setActionCommand(cmdPrintPreview);
        jmiExit.setActionCommand(cmdExit);
        jmiUndo.setActionCommand(cmdUndo);
        jmiRedo.setActionCommand(cmdRedo);
        jmiCut.setActionCommand(cmdCut);
        jmiCopy.setActionCommand(cmdCopy);
        jmiPaste.setActionCommand(cmdPaste);
        jmiAttach.setActionCommand(cmdAttach);
        jmiDelete.setActionCommand(cmdDelete);
        jmiEdit.setActionCommand(cmdEdit);
        jmiMoveUp.setActionCommand(cmdUp);
        jmiMoveDown.setActionCommand(cmdDown);
        jmiResultant.setActionCommand(cmdResultant);
        jmiEnergy.setActionCommand(cmdEnergy);

        this.menuBar.add(jmFile);
        this.menuBar.add(jmEdit);
        this.menuBar.add(jmSimulate);
        this.menuBar.add(jmHelp);
        //endregion
    }

    /**
     * Overridden method from the superclass to setup the toolbar
     * of the user interface that contains all common actions
     * relevant to the problem set.
     */
    @Override
    protected void setupToolbar() {
        //region Button Declarations and Initialization
        JButton btnNew = new JButton(icoNew);
        JButton btnOpen = new JButton(icoOpen);
        JButton btnSave = new JButton(icoSave);

        JButton btnPrint = new JButton(icoPrint);
        JButton btnPrintPreview = new JButton(icoPrintPreview);

        JButton btnUndo = new JButton(icoUndo);
        JButton btnRedo = new JButton(icoRedo);

        JButton btnCut = new JButton(icoCut);
        JButton btnCopy = new JButton(icoCopy);
        JButton btnPaste = new JButton(icoPaste);

        JButton btnAttach = new JButton(icoAttach);
        JButton btnDelete = new JButton(icoDelete);
        JButton btnEdit = new JButton(icoEdit);

        JButton btnUp = new JButton(icoUp);
        JButton btnDown = new JButton(icoDown);

        JToggleButton btnLock = new JToggleButton(icoLock);
        JButton btnZoom = new JButton(icoZoom);

        JButton btnResultant = new JButton(icoResultant);
        JButton btnEnergy = new JButton(icoEnergy);
        JLabel lblHeadSize = new JLabel("Arrow Head Size: ");
        final JSlider sldrHeadSize = new JSlider(SwingConstants.HORIZONTAL, 3, 20, 15);

        sldrHeadSize.setMaximumSize(new Dimension(100, 50));

        //endregion

        //region Button Focus
        btnNew.setFocusable(false);
        btnOpen.setFocusable(false);
        btnSave.setFocusable(false);
        btnPrint.setFocusable(false);
        btnPrintPreview.setFocusable(false);
        btnUndo.setFocusable(false);
        btnRedo.setFocusable(false);
        btnCut.setFocusable(false);
        btnCopy.setFocusable(false);
        btnPaste.setFocusable(false);
        btnAttach.setFocusable(false);
        btnDelete.setFocusable(false);
        btnEdit.setFocusable(false);
        btnUp.setFocusable(false);
        btnDown.setFocusable(false);
        btnLock.setFocusable(false);
        btnZoom.setFocusable(false);
        btnResultant.setFocusable(false);
        btnEnergy.setFocusable(false);
        sldrHeadSize.setFocusable(false);
        //endregion

        //region Button Action Listeners
        btnNew.addActionListener(ctrlList);
        btnOpen.addActionListener(ctrlList);
        btnSave.addActionListener(ctrlList);

        btnPrint.addActionListener(ctrlList);
        btnPrintPreview.addActionListener(ctrlList);

        btnUndo.addActionListener(ctrlList);
        btnRedo.addActionListener(ctrlList);

        btnCut.addActionListener(ctrlList);
        btnCopy.addActionListener(ctrlList);
        btnPaste.addActionListener(ctrlList);

        btnAttach.addActionListener(ctrlList);
        btnDelete.addActionListener(ctrlList);
        btnEdit.addActionListener(ctrlList);

        btnUp.addActionListener(ctrlList);
        btnDown.addActionListener(ctrlList);

        btnLock.addActionListener(ctrlList);
        btnResultant.addActionListener(ctrlList);
        btnZoom.addActionListener(ctrlList);
        btnEnergy.addActionListener(ctrlList);
        //endregion

        //region Button Action Commands
        btnNew.setActionCommand(cmdNew);
        btnOpen.setActionCommand(cmdOpen);
        btnSave.setActionCommand(cmdSave);

        btnPrint.setActionCommand(cmdPrint);
        btnPrintPreview.setActionCommand(cmdPrintPreview);

        btnUndo.setActionCommand(cmdUndo);
        btnRedo.setActionCommand(cmdRedo);

        btnCut.setActionCommand(cmdCut);
        btnCopy.setActionCommand(cmdCopy);
        btnPaste.setActionCommand(cmdPaste);

        btnAttach.setActionCommand(cmdAttach);
        btnDelete.setActionCommand(cmdDelete);
        btnEdit.setActionCommand(cmdEdit);

        btnUp.setActionCommand(cmdUp);
        btnDown.setActionCommand(cmdDown);

        btnLock.setActionCommand(cmdLock);
        btnResultant.setActionCommand(cmdResultant);
        btnZoom.setActionCommand(cmdZoom);
        btnEnergy.setActionCommand(cmdEnergy);

        //endregion

        sldrHeadSize.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                forceView.setArrow(sldrHeadSize.getValue());
            }
        });

        //region Toolbar addition
        this.toolBar.add(btnNew);
        this.toolBar.add(btnSave);
        this.toolBar.add(btnOpen);
        this.toolBar.addSeparator();
        this.toolBar.add(btnPrint);
        this.toolBar.add(btnPrintPreview);
        this.toolBar.addSeparator();
        this.toolBar.add(btnUndo);
        this.toolBar.add(btnRedo);
        this.toolBar.addSeparator();
        this.toolBar.add(btnCut);
        this.toolBar.add(btnCopy);
        this.toolBar.add(btnPaste);
        this.toolBar.addSeparator();
        this.toolBar.add(btnAttach);
        this.toolBar.add(btnDelete);
        this.toolBar.add(btnEdit);
        this.toolBar.addSeparator();
        this.toolBar.add(btnUp);
        this.toolBar.add(btnDown);
        this.toolBar.addSeparator();
        this.toolBar.add(btnLock);
        this.toolBar.add(btnZoom);
        this.toolBar.addSeparator();
        this.toolBar.add(btnResultant);
        this.toolBar.add(btnEnergy);
        this.toolBar.addSeparator();
        this.toolBar.add(lblHeadSize);
        this.toolBar.add(sldrHeadSize);
        //endregion
    }

    /**
     * Overridden method from the superclass to setup
     * the rest of the user interface that contains
     * the JForceView and JList components.
     */
    @Override
    protected void setupContent() {
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        JScrollPane scrollPane = new JScrollPane();

        scrollPane.setViewportView(forceList);

        splitPane.setLeftComponent(scrollPane);
        splitPane.setRightComponent(forceView);

        this.content.add(splitPane);
    }

    /**
     * Overridden method from the superclass to initialize
     * all variables and components necessary in the view and
     * initialize the ForceModel and the ForceListController classes.
     */
    @Override
    protected void preSetup() {
        ArrayList<Force> forces = new ArrayList<>();
        this.forceList = new JList<>();
        this.forceView = new JForceView();

        ForceModel model = new ForceModel(forces, forceList, forceView);

        this.ctrlList = new ForcesListController(model);
    }

    /**
     * Overridden method from the superclass to perform
     * any additional actions after all UI components
     * have been added to the screen.
     */
    @Override
    protected void postSetup() {
        this.forceList.getInputMap().clear();
    }
}
