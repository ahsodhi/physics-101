package application.content;

import static application.shared.Assets.*;

import application.components.JVectorView;
import application.controllers.VectorsListController;
import application.models.VectorModel;
import application.structures.Vector;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.util.ArrayList;

/**
 * Created by:  Jinesh Patel
 * Date:        2016-01-09
 * File:        ${FILE_NAME}
 * Description: The View for the vectors unit.
 */
public class VectorsUI extends MainFrameUI {
    private JList<String> vectorsList;
    private JVectorView vectorView;

    private VectorsListController ctrlList;

    protected void setupMenu() {
        JMenu jmFile = createJMenu("File", 'F');
        JMenu jmEdit = createJMenu("Edit", 'E');
        JMenu jmSimulate = createJMenu("Simulate", 'S');
        JMenu jmHelp = createJMenu("Help", 'H');

        JMenuItem jmiNew = createJMenuItem("New", 'N', icoNew, ksNew);
        JMenuItem jmiOpen = createJMenuItem("Open", 'O', icoOpen, ksOpen);
        JMenuItem jmiSave = createJMenuItem("Save", 'S', icoSave, ksSave);
        JMenuItem jmiSaveAs = createJMenuItem("Save As", 'v', null, ksSaveAs);
        JMenuItem jmiPrint = createJMenuItem("Print", 'P', icoPrint, ksPrint);
        JMenuItem jmiPrintPreview = createJMenuItem("Print Preview", 'r', icoPrintPreview, ksPrintPreview);
        JMenuItem jmiExit = createJMenuItem("Exit", 'x', null, null);

        jmFile.add(jmiNew);
        jmFile.addSeparator();
        jmFile.add(jmiOpen);
        jmFile.addSeparator();
        jmFile.add(jmiSave);
        jmFile.add(jmiSaveAs);
        jmFile.addSeparator();
        jmFile.add(jmiPrint);
        jmFile.add(jmiPrintPreview);
        jmFile.addSeparator();
        jmFile.add(jmiExit);

        JMenuItem jmiUndo = createJMenuItem("Undo", 'U', icoUndo, ksUndo);
        JMenuItem jmiRedo = createJMenuItem("Redo", 'R', icoRedo, ksRedo);
        JMenuItem jmiCut = createJMenuItem("Cut", 'u', icoCut, ksCut);
        JMenuItem jmiCopy = createJMenuItem("Copy", 'C', icoCopy, ksCopy);
        JMenuItem jmiPaste = createJMenuItem("Paste", 'P', icoPaste, ksPaste);

        jmEdit.add(jmiUndo);
        jmEdit.add(jmiRedo);
        jmEdit.addSeparator();
        jmEdit.add(jmiCut);
        jmEdit.add(jmiCopy);
        jmEdit.add(jmiPaste);

        JMenuItem jmiAttach = createJMenuItem("Attach", 'A', icoAttach, ksAttach);
        JMenuItem jmiDelete = createJMenuItem("Delete", 'D', icoDelete, ksDelete);
        JMenuItem jmiEdit = createJMenuItem("Edit", 'E', icoEdit, ksEdit);
        JMenuItem jmiMoveUp = createJMenuItem("Move Up", 'U', icoUp, ksUp);
        JMenuItem jmiMoveDown = createJMenuItem("Move Down", 'D', icoDown, ksDown);
        JMenuItem jmiRun = createJMenuItem("Run", 'R', icoRun, ksRun);
        JMenuItem jmiResultant = createJMenuItem("Resultant", 'e', icoResultant, ksResultant);
        JMenuItem jmiExport = createJMenuItem("Export", 'x', null, null);

        jmSimulate.add(jmiAttach);
        jmSimulate.add(jmiDelete);
        jmSimulate.add(jmiEdit);
        jmSimulate.add(jmiMoveUp);
        jmSimulate.add(jmiMoveDown);
        jmSimulate.addSeparator();
        jmSimulate.add(jmiRun);
        jmSimulate.add(jmiResultant);
        jmSimulate.addSeparator();
        jmSimulate.add(jmiExport);

        this.menuBar.add(jmFile);
        this.menuBar.add(jmEdit);
        this.menuBar.add(jmSimulate);
        this.menuBar.add(jmHelp);
    }

    protected void setupToolbar() {
        JButton btnNew = new JButton(icoNew);
        JButton btnOpen = new JButton(icoOpen);
        JButton btnSave = new JButton(icoSave);
        JButton btnPrint = new JButton(icoPrint);
        JButton btnUndo = new JButton(icoUndo);
        JButton btnRedo = new JButton(icoRedo);
        JButton btnCut = new JButton(icoCut);
        JButton btnCopy = new JButton(icoCopy);
        JButton btnPaste = new JButton(icoPaste);
        JButton btnAttach = new JButton(icoAttach);
        JButton btnDelete = new JButton(icoDelete);
        JButton btnEdit = new JButton(icoEdit);
        JButton btnUp = new JButton(icoUp);
        JButton btnDown = new JButton(icoDown);
        JButton btnRun = new JButton(icoRun);
        JButton btnResultant = new JButton(icoResultant);
        JToggleButton btnLock = new JToggleButton(icoLock);
        JButton btnZoom = new JButton(icoZoom);
        JLabel lblHeadSize = new JLabel("Arrow Head Size: ");
        final JSlider sldrHeadSize = new JSlider(SwingConstants.HORIZONTAL, 3, 20, 15);

        sldrHeadSize.setMaximumSize(new Dimension(100, 50));

        btnNew.setFocusable(false);
        btnOpen.setFocusable(false);
        btnSave.setFocusable(false);
        btnPrint.setFocusable(false);
        btnUndo.setFocusable(false);
        btnRedo.setFocusable(false);
        btnCut.setFocusable(false);
        btnCopy.setFocusable(false);
        btnPaste.setFocusable(false);
        btnAttach.setFocusable(false);
        btnDelete.setFocusable(false);
        btnEdit.setFocusable(false);
        btnUp.setFocusable(false);
        btnDown.setFocusable(false);
        btnRun.setFocusable(false);
        btnResultant.setFocusable(false);
        btnLock.setFocusable(false);
        btnZoom.setFocusable(false);
        sldrHeadSize.setFocusable(false);

        btnAttach.addActionListener(ctrlList);
        btnEdit.addActionListener(ctrlList);
        btnDelete.addActionListener(ctrlList);
        btnUp.addActionListener(ctrlList);
        btnDown.addActionListener(ctrlList);

        btnCut.addActionListener(ctrlList);
        btnCopy.addActionListener(ctrlList);
        btnPaste.addActionListener(ctrlList);

        btnUndo.addActionListener(ctrlList);
        btnRedo.addActionListener(ctrlList);

        btnSave.addActionListener(ctrlList);
        btnOpen.addActionListener(ctrlList);
        btnNew.addActionListener(ctrlList);

        btnPrint.addActionListener(ctrlList);
        btnZoom.addActionListener(ctrlList);

        btnRun.addActionListener(ctrlList);
        btnResultant.addActionListener(ctrlList);

        btnLock.addActionListener(ctrlList);

        btnAttach.setActionCommand(cmdAttach);
        btnDelete.setActionCommand(cmdDelete);
        btnUp.setActionCommand(cmdUp);
        btnDown.setActionCommand(cmdDown);
        btnEdit.setActionCommand(cmdEdit);

        btnCut.setActionCommand(cmdCut);
        btnCopy.setActionCommand(cmdCopy);
        btnPaste.setActionCommand(cmdPaste);

        btnUndo.setActionCommand(cmdUndo);
        btnRedo.setActionCommand(cmdRedo);

        btnSave.setActionCommand(cmdSave);
        btnOpen.setActionCommand(cmdOpen);
        btnNew.setActionCommand(cmdNew);

        btnPrint.setActionCommand(cmdPrint);

        btnZoom.setActionCommand(cmdZoom);
        btnLock.setActionCommand(cmdLock);

        btnResultant.setActionCommand(cmdResultant);
        btnRun.setActionCommand(cmdRun);

        sldrHeadSize.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                vectorView.setArrow(sldrHeadSize.getValue());
            }
        });

        this.toolBar.add(btnNew);
        this.toolBar.add(btnSave);
        this.toolBar.add(btnOpen);
        this.toolBar.addSeparator();
        this.toolBar.add(btnUndo);
        this.toolBar.add(btnRedo);
        this.toolBar.addSeparator();
        this.toolBar.add(btnCut);
        this.toolBar.add(btnCopy);
        this.toolBar.add(btnPaste);
        this.toolBar.addSeparator();
        this.toolBar.add(btnAttach);
        this.toolBar.add(btnDelete);
        this.toolBar.add(btnEdit);
        this.toolBar.addSeparator();
        this.toolBar.add(btnUp);
        this.toolBar.add(btnDown);
        this.toolBar.addSeparator();
        this.toolBar.add(btnRun);
        this.toolBar.add(btnResultant);
        this.toolBar.addSeparator();
        this.toolBar.add(btnLock);
        this.toolBar.add(btnZoom);
        this.toolBar.add(lblHeadSize);
        this.toolBar.add(sldrHeadSize);
    }

    protected void setupContent() {
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        JScrollPane scrollPane = new JScrollPane();

        scrollPane.setViewportView(vectorsList);

        splitPane.setLeftComponent(scrollPane);
        splitPane.setRightComponent(vectorView);

        this.content.add(splitPane);
    }

    @Override
    protected void preSetup() {
        ArrayList<Vector> vectorsData = new ArrayList<>();
        this.vectorsList = new JList<>();
        this.vectorView = new JVectorView();

        VectorModel model = new VectorModel(vectorsList, vectorView, vectorsData);

        this.ctrlList = new VectorsListController(model);
    }

    @Override
    protected void postSetup() {

    }
}
