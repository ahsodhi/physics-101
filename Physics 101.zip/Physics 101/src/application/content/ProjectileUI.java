package application.content;

/**
 * Created by:  Jinesh Patel
 * Date:        2016-01-19
 * File:        ${FILE_NAME}
 * Description:
 */
public class ProjectileUI extends MainFrameUI {
    @Override
    protected void setupMenu() {

    }

    @Override
    protected void setupToolbar() {

    }

    @Override
    protected void setupContent() {

    }

    @Override
    protected void preSetup() {

    }

    @Override
    protected void postSetup() {

    }
}
