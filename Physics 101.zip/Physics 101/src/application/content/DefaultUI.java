package application.content;

/**
 * Created by:  Jinesh Patel
 * Date:        2016-01-11
 * File:        ${FILE_NAME}
 * Description:
 */
public class DefaultUI extends MainFrameUI {
    @Override
    protected void setupMenu() {
        
    }

    @Override
    protected void setupToolbar() {

    }

    @Override
    protected void setupContent() {

    }

    @Override
    protected void preSetup() {

    }

    @Override
    protected void postSetup() {

    }
}
