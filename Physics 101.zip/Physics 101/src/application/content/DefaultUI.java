package application.content;


public class DefaultUI extends MainFrameUI {
    @Override
    protected void setupMenu() {
        
    }

    @Override
    protected void setupToolbar() {

    }

    @Override
    protected void setupContent() {

    }

    @Override
    protected void preSetup() {

    }

    @Override
    protected void postSetup() {

    }
}
