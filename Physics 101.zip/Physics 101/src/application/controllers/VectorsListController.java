package application.controllers;

import application.models.VectorModel;
import application.utils.FileUtils;

import static application.shared.Assets.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by:  Jinesh Patel
 * Date:        2016-01-14
 * File:        ${FILE_NAME}
 * Description:
 */
public class VectorsListController implements ActionListener {
    private final VectorModel model;

    public VectorsListController(VectorModel model) {
        this.model = model;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case cmdAttach:
                this.model.attach();
                break;
            case cmdDelete:
                this.model.delete();
                break;
            case cmdDown:
                this.model.movedown();
                break;
            case cmdUp:
                this.model.moveup();
                break;
            case cmdEdit:
                this.model.edit();
                break;
            case cmdCut:
                this.model.cut();
                break;
            case cmdCopy:
                this.model.copy();
                break;
            case cmdPaste:
                this.model.paste();
                break;
            case cmdUndo:
                this.model.undo();
                break;
            case cmdRedo:
                this.model.redo();
                break;
            case cmdSave:
                FileUtils.saveFile(model, "Vector File", "vctr");
                break;
            case cmdOpen:
                FileUtils.openFile(model, "Vector File", "vctr");
                break;
            case cmdNew:
                FileUtils.newFile(model, "Vector File", "vctr");
                break;
            case cmdResultant:
                this.model.showCalculator();
                break;
            case cmdLock:
                this.model.toggleLock();
                break;
            case cmdZoom:
                this.model.zoom();
                break;
        }
    }
}
