package application.controllers;

import application.models.ForceModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static application.shared.Assets.*;

/**
 * Created by:  Hassaan Zaki
 * Date:        2016-01-14
 * File:        ${FILE_NAME}
 * Description:
 */
public class ForcesListController implements ActionListener {
    private final ForceModel model;

    public ForcesListController(ForceModel model) {
        this.model = model;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case cmdAttach:
                this.model.attach();
                break;
            case cmdDelete:
                this.model.delete();
                break;
            case cmdDown:
                this.model.movedown();
                break;
            case cmdUp:
                this.model.moveup();
                break;
            case cmdEdit:
                this.model.edit();
                break;
            case cmdCut:
                this.model.cut();
                break;
            case cmdCopy:
                this.model.copy();
                break;
            case cmdPaste:
                this.model.paste();
                break;
            case cmdUndo:
                this.model.undo();
                break;
            case cmdRedo:
                this.model.redo();
                break;
            case cmdSave:
                this.model.saveFile();
                break;
            case cmdSaveAs:
                this.model.saveAsFile();
                break;
            case cmdOpen:
                this.model.openFile();
                break;
            case cmdNew:
                this.model.newFile();
                break;
            case cmdResultant:
                this.model.showResultant();
                break;
            case cmdLock:
                this.model.toggleLocked();
                break;
            case cmdZoom:
                this.model.zoom();
                break;
            case cmdPrint:
                this.model.print();
                break;
            case cmdExit:
                this.model.exit();
                break;
            case cmdPrintPreview:
                this.model.preview();
                break;
            case cmdEnergy:
                this.model.energy();
                break;
        }
    }
}
