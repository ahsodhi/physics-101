package application.models;

import application.components.JVectorView;
import application.structures.Vector;
import application.utils.CalculationUtils;
import application.utils.ListUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by:  Jinesh Patel
 * Date:        2016-01-16
 * File:        ${FILE_NAME}
 * Description:
 */
public class VectorModel extends DataModel<Vector> {
    //region Visual Components

    private final JList<String> list;
    private final JVectorView view;

    //endregion

    //region Constructors

    public VectorModel(JList<String> list, JVectorView view, ArrayList<Vector> items) {
        super(items);
        this.list = list;
        this.view = view;

        this.initDialog();
        this.layoutDialog();
        this.styleDialog();

        this.init();
        this.layout();
        this.style();
    }

    public void zoom() {
        view.zoom();
    }

    //endregion

    //region Data Type Information

    @Override
    protected Class getDataType() {
        return Vector.class;
    }

    //endregion

    //region List Methods

    public void cut() {
        super.cut(list.getSelectedIndices());
    }

    public void copy() {
        super.copy(list.getSelectedIndices());
    }

    public void paste() {
        super.paste();
    }

    public void attach() {
        Vector vector = this.getVectorInfo();

        if (vector != null)
            super.attach(vector);
    }

    public void delete() {
        super.delete(list.getSelectedIndex());
    }

    public void edit() {
        Vector vector = this.getVectorInfo(data.get(list.getSelectedIndex()));

        if (vector != null)
            super.edit(vector, list.getSelectedIndex());
    }

    public void movedown() {
        super.movedown(list.getSelectedIndex());
    }

    public void moveup() {
        super.moveup(list.getSelectedIndex());
    }

    @Override
    protected void update() {
        String[] names = new String[data.size()];

        for (int index = 0; index < data.size(); index++)
            names[index] = data.get(index).getName();

        this.list.setListData(names);
        this.view.setItems(data);
    }

    //endregion

    //region Dialog

    //region Dialog Components

    private JPanel dialog;

    private JFormattedTextField fldName;
    private JFormattedTextField fldAngle;
    private JFormattedTextField fldMagnitude;
    private JComboBox<Vector.VectorMode> fldMode;
    private JPanel fldColor;

    private JLabel lblName;
    private JLabel lblMagnitude;
    private JLabel lblAngle;
    private JLabel lblColor;
    private JLabel lblMode;

    //endregion

    //region Dialog Creator Methods

    private void layoutDialog() {
        GridBagConstraints constraints = new GridBagConstraints();

        constraints.fill = GridBagConstraints.BOTH;
        constraints.insets = new Insets(1, 1, 1, 1);
        constraints.weightx = 1;
        constraints.weighty = 0;

        constraints.gridx = 1;
        constraints.gridy = 1;

        dialog.add(fldName, constraints);

        constraints.gridx = 1;
        constraints.gridy = 2;

        dialog.add(fldMagnitude, constraints);

        constraints.gridx = 1;
        constraints.gridy = 3;

        dialog.add(fldAngle, constraints);

        constraints.gridx = 1;
        constraints.gridy = 4;

        dialog.add(fldColor, constraints);

        constraints.gridx = 1;
        constraints.gridy = 5;

        dialog.add(fldMode, constraints);

        constraints.gridwidth = 1;

        constraints.weightx = 0;
        constraints.weighty = 0;
        constraints.ipadx = 25;

        constraints.gridx = 0;
        constraints.gridy = 1;

        dialog.add(lblName, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;

        dialog.add(lblMagnitude, constraints);

        constraints.gridx = 0;
        constraints.gridy = 3;

        dialog.add(lblAngle, constraints);

        constraints.gridx = 0;
        constraints.gridy = 4;

        dialog.add(lblColor, constraints);

        constraints.gridx = 0;
        constraints.gridy = 5;

        dialog.add(lblMode, constraints);
    }

    private void styleDialog() {
        this.fldColor.setBackground(Color.BLACK);
    }

    private void initDialog() {
        this.dialog = new JPanel(new GridBagLayout());

        this.fldName = new JFormattedTextField();
        this.fldMagnitude = new JFormattedTextField(0d);
        this.fldAngle = new JFormattedTextField(0d);
        this.fldColor = new JPanel();
        this.fldMode = new JComboBox<>(Vector.VectorMode.values());

        this.lblName = new JLabel("Name:");
        this.lblMagnitude = new JLabel("Magnitude:");
        this.lblAngle = new JLabel("Angle:");
        this.lblColor = new JLabel("Color:");
        this.lblMode = new JLabel("Mode:");
    }

    //endregion

    //region Dialog Data Methods

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    private boolean isDataValid() {
        return this.getVectorName().length() > 0 && this.getMagnitude() > 0;
    }

    private void loadData(Vector info) {
        this.setVectorName(info.getName());
        this.setAngle(info.getAngle());
        this.setMagnitude(info.getMagnitude());
        this.setColor(info.getColor());
        this.setMode(info.getMode());
    }

    private Vector getData() {
        return new Vector(
                this.getVectorName(),
                this.data.size() > 0 ? ListUtils.getLast(data).getEndX() : 0,
                this.data.size() > 0 ? ListUtils.getLast(data).getEndY() : 0,
                this.getMagnitude(),
                this.getAngle(),
                this.getColor(),
                this.getVectorMode());
    }

    private Vector getVectorInfo(Vector data) {
        if (data != null)
            loadData(data);

        do {
            if (JOptionPane.showConfirmDialog(
                    null,
                    dialog,
                    "Vector Info",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE) != JOptionPane.OK_OPTION)
                return null;

            if (!isDataValid())
                JOptionPane.showMessageDialog(
                        null,
                        "Invalid data was entered.",
                        "Message",
                        JOptionPane.ERROR_MESSAGE,
                        null);

        } while (!isDataValid());

        return getData();
    }

    private Vector getVectorInfo() {
        return this.getVectorInfo(null);
    }

    //endregion

    //region Dialog Field Getters & Setters

    private String getVectorName() {
        return fldName.getText();
    }

    private double getMagnitude() {
        return ((double) fldMagnitude.getValue());
    }

    private double getAngle() {
        return ((double) fldAngle.getValue());
    }

    private Color getColor() {
        return fldColor.getBackground();
    }

    private Vector.VectorMode getVectorMode() {
        return fldMode.getItemAt(fldMode.getSelectedIndex());
    }

    private void setVectorName(String name) {
        this.fldName.setText(name);
    }

    private void setAngle(double angle) {
        this.fldAngle.setValue(angle);
    }

    private void setMagnitude(double magnitude) {
        this.fldMagnitude.setValue(magnitude);
    }

    private void setColor(Color color) {
        this.fldColor.setBackground(color);
    }

    private void setMode(Vector.VectorMode mode) {
        this.fldMode.setSelectedItem(mode);
    }

    //endregion

    //endregion
    
    //region Calculator

    private JPanel calculator;

    private JTable table;

    private void layout() {
        calculator.add(new JScrollPane(this.table));
    }

    private void style() {
        calculator.setBackground(Color.LIGHT_GRAY);

        table.setShowHorizontalLines(false);
        table.setRowMargin(5);
        table.setEnabled(false);
    }

    public void showCalculator() {
        Object[][] table = new Object[data.size() + 1][5];
        String[] titles = {"Name", "Magnitude", "Angle", "X-Comp", "Y-Comp"};

        for (int i = 0; i < data.size(); i++) {
            table[i] = new Object[] {
                    data.get(i).getName(),
                    CalculationUtils.round(data.get(i).getMagnitude(), 2),
                    CalculationUtils.round(data.get(i).getAngle(), 2),
                    CalculationUtils.round(CalculationUtils.getXComponent(data.get(i).getMagnitude(), data.get(i).getAngle()), 2),
                    CalculationUtils.round(CalculationUtils.getYComponent(data.get(i).getMagnitude(), data.get(i).getAngle()), 2)
            };
        }

        table[table.length - 1] = new Object[] {
                "Resultant",
                CalculationUtils.round(CalculationUtils.getSumMagnitude(data.toArray(new Vector[data.size()])), 2),
                CalculationUtils.round(CalculationUtils.getSumAngle(data.toArray(new Vector[data.size()])), 2),
                CalculationUtils.round(CalculationUtils.getSumX(data.toArray(new Vector[data.size()])), 2),
                CalculationUtils.round(CalculationUtils.getSumY(data.toArray(new Vector[data.size()])), 2)
        };

        this.table.setModel(new DefaultTableModel(table, titles));

        JOptionPane.showMessageDialog(null, calculator, "Resultant", JOptionPane.PLAIN_MESSAGE);
    }

    private void init() {
        this.calculator = new JPanel(new BorderLayout());

        this.table = new JTable();
    }

    //endregion

    //region FileIO

    @Override
    public void read(Scanner in) {
        while (in.hasNext()) {
            int startX = this.data.size() > 0 ? ListUtils.getLast(data).getEndX() : 0;
            int startY = this.data.size() > 0 ? ListUtils.getLast(data).getEndY() : 0;
            double magnitude = in.nextDouble();
            double angle = in.nextDouble();
            Color color = new Color(in.nextInt(), in.nextInt(), in.nextInt());
            Vector.VectorMode mode = Vector.VectorMode.valueOf(in.next());
            String name = in.nextLine().substring(1);

            data.add(new Vector(name,
                    startX,
                    startY,
                    magnitude,
                    angle,
                    color,
                    mode));
        }

        this.update();
    }

    @Override
    public void write(PrintWriter out) {
        for (Vector v : data) {
            out.print(v.getMagnitude() + " ");
            out.print(v.getAngle() + " ");
            out.print(v.getColor().getRed() + " ");
            out.print(v.getColor().getGreen() + " ");
            out.print(v.getColor().getBlue() + " ");
            out.print(v.getMode().toString() + " ");
            out.print(v.getName() + " ");
            out.println();
        }

        this.update();
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        return 0;
    }

    //endregion

    public void toggleLock() {
        view.setLocked(!view.isLocked());
    }
}
