package application.models;

import application.components.JForceView;
import application.structures.Force;
import static application.utils.CalculationUtils.*;

import application.utils.CalculationUtils;
import application.utils.FileUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by:  Hassaan Zaki
 * Date:        2016-01-16
 * File:        application.models.ForceModel.java
 * Description: Force model
 */
public class ForceModel extends DataModel<Force> {

    //region Variables
    private final JList<String> list;
    private final JForceView view;

    private JPanel dialog;
    private JPanel energy;

    private JFormattedTextField fldName;
    private JFormattedTextField fldMagnitude;
    private JFormattedTextField fldAngle;
    private JPanel fldColor;

    private JLabel lblName;
    private JLabel lblColor;
    private JLabel lblMagnitude;
    private JLabel lblAngle;

    private JFormattedTextField fldDistance;
    private JLabel lblDistance;

    private final PrinterJob job;
    //endregion

    //region Constructor
    /**
     * Constructor
     * @param data
     * @param list
     * @param view
     */
    public ForceModel(ArrayList<Force> data, JList<String> list, JForceView view) {
        super(data);
        this.list = list;
        this.view = view;

        this.initDialog();
        this.layoutDialog();
        this.styleDialog();

        this.initializeResultant();
        this.layoutResultant();
        this.styleResultant();

        this.energyInitDialog();
        this.energyLayoutDialog();
        this.energyStyleDialog();

        this.job = PrinterJob.getPrinterJob();
    }
    //endregion

    //region Data Type Information

    /**
     * Gets the type of the class
     * @return The class type
     */
    @Override
    protected Class getDataType() {
        return Force.class;
    }
    //endregion

    //region FileIO

    /**
     * Reads the file
     * @param in Scanner element
     */
    @Override
    public void read(Scanner in) {
        //While there is another line the get the size of the vector
        while (in.hasNext()) {
            double magnitude = in.nextDouble();
            double angle = in.nextDouble();
            int r = in.nextInt();
            int g = in.nextInt();
            int b = in.nextInt();
            String name = in.nextLine();

            Color a = new Color(r,g,b);

            data.add(new Force(
                    name,
                    magnitude,
                    angle,
                    a));
        }

        this.update();
    }

    /**
     * Write method for File IO
     * @param out Printwriter
     */
    @Override
    public void write(PrintWriter out) {
        for (Force f : data) {
            out.print(f.getMagnitude() + " ");
            out.print(f.getAngle() + " ");
            out.print(f.getColor().getRed() + " ");
            out.print(f.getColor().getGreen() + " ");
            out.print(f.getColor().getBlue() + " ");
            out.print(f.getName());
            out.println();
        }
    }
    //endregion

    //region Force Info

    /**
     * Getter for the force Info
     * @return the force info
     */
    private Force getInfo() {
        return this.getInfo(null);
    }

    /**
     * Gets the info about the force vector
     * @param data The force object
     * @return the Force name, magnitude, angle and colour
     */
    private Force getInfo(Force data) {
        if (data != null)
            loadData(data);

        do {
            if (JOptionPane.showConfirmDialog(
                    null,
                    dialog,
                    "Force Info",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE) != JOptionPane.OK_OPTION)
                return null;

            if (!isDataValid())
                JOptionPane.showMessageDialog(
                        null,
                        "Invalid data was entered.",
                        "Message",
                        JOptionPane.ERROR_MESSAGE,
                        null);

        } while (!isDataValid());

        return new Force(
                getForceName(),
                getMagnitude(),
                getAngle(),
                getColor());
    }

    //endregion

    //region Force Dialog

    /**
     * Layout for the force input
     */
    private void layoutDialog() {
        GridBagConstraints constraints = new GridBagConstraints();

        constraints.anchor = GridBagConstraints.LINE_START;
        constraints.weightx = 0;
        constraints.weighty = 0;
        constraints.ipadx = 25;
        constraints.insets = new Insets(1, 1, 1, 1);

        constraints.gridx = 0;
        constraints.gridy = 0;

        dialog.add(lblName, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;

        dialog.add(lblMagnitude, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;

        dialog.add(lblAngle, constraints);

        constraints.gridx = 0;
        constraints.gridy = 3;

        dialog.add(lblColor, constraints);

        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.weightx = 1;
        constraints.weighty = 0;
        constraints.ipadx = 0;
        constraints.gridwidth = 2;
        constraints.fill = GridBagConstraints.BOTH;

        constraints.gridx = 1;
        constraints.gridy = 0;

        dialog.add(fldName, constraints);

        constraints.gridx = 1;
        constraints.gridy = 1;

        dialog.add(fldMagnitude, constraints);

        constraints.gridx = 1;
        constraints.gridy = 2;

        dialog.add(fldAngle, constraints);

        constraints.gridx = 1;
        constraints.gridy = 3;

        dialog.add(fldColor, constraints);
    }

    /**
     * Style for the force Dialog
     */
    private void styleDialog() {
        fldColor.setBackground(Color.BLACK);
    }

    /**
     * Initializes all the variables
     */
    private void initDialog() {
        this.dialog = new JPanel(new GridBagLayout());

        this.lblName = new JLabel("Name:");
        this.lblColor = new JLabel("Color:");
        this.lblMagnitude = new JLabel("Magnitude:");
        this.lblAngle = new JLabel("Angle:");

        this.fldName = new JFormattedTextField("");
        this.fldMagnitude = new JFormattedTextField(0d);
        this.fldAngle = new JFormattedTextField(0d);
        this.fldColor = new JPanel();
    }
    //endregion

    //region Energy Dialog

    /**
     * Layout for the energy
     */
    private void energyLayoutDialog() {
        GridBagConstraints constraints = new GridBagConstraints();

        constraints.anchor = GridBagConstraints.LINE_START;
        constraints.weightx = 0;
        constraints.weighty = 0;
        constraints.ipadx = 25;
        constraints.insets = new Insets(1, 1, 1, 1);

        constraints.gridx = 0;
        constraints.gridy = 0;

        energy.add(lblDistance, constraints);

        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.weightx = 1;
        constraints.weighty = 0;
        constraints.ipadx = 0;
        constraints.gridwidth = 2;
        constraints.fill = GridBagConstraints.BOTH;

        constraints.gridx = 1;
        constraints.gridy = 0;

        energy.add(fldDistance, constraints);
    }

    /**
     * Styles the energy dialog box
     */
    private void energyStyleDialog() {
        fldColor.setBackground(Color.BLACK);
    }

    /**
     * Initializes all the energy Variables
     */
    private void energyInitDialog() {
        this.energy = new JPanel(new GridBagLayout());

        this.lblDistance = new JLabel("Distance:");

        this.fldDistance = new JFormattedTextField(0d);
    }
    //endregion

    //region Data Check

    /**
     * Checking if the data is valid
     * @return boolean
     */
    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    private boolean isDataValid() {
        return getMagnitude() > 0 && getForceName().length() > 0;
    }

    /**
     * Load's the force info
     * @param info force object
     */
    private void loadData(Force info) {
        setForceName(info.getName());
        setAngle(info.getAngle());
        setMagnitude(info.getMagnitude());
        setColor(info.getColor());
    }
    //endregion

    //region Getters and Setter

    /**
     * Getter for Force Name
     * @return Name of the force
     */
    private String getForceName() {
        return fldName.getText();
    }

    /**
     * Getter for force magnitude
     * @return force magnitude
     */
    private double getMagnitude() {
        return ((double) fldMagnitude.getValue());
    }

    /**
     * Getter for force angle
     * @return force angle
     */
    private double getAngle() {
        return ((double) fldAngle.getValue());
    }

    /**
     * Getter for force colour
     * @return force colour
     */
    private Color getColor() {
        return fldColor.getBackground();
    }

    /**
     * Setter for force name
     * @param name name of the force
     */
    private void setForceName(String name) {
        this.fldName.setValue(name);
    }

    /**
     * Setter for force angle
     * @param angle force angle
     */
    private void setAngle(double angle) {
        this.fldAngle.setValue(angle);
    }

    /**
     * Setter for force magnitude
     * @param magnitude force magnitude
     */
    private void setMagnitude(double magnitude) {
        this.fldMagnitude.setValue(magnitude);
    }

    /**
     * Setter for force colour
     * @param color force colour
     */
    private void setColor (Color color) {
        this.fldColor.setBackground(color);
    }

    /**
     * Getter for energy Distance
     * @return energy distance
     */
    private double getDistance() {
        return ((double) fldDistance.getValue());
    }
    //endregion

    //region List Methods
    /**
     * Update Method
     */
    protected void update() {
        String[] names = new String[data.size()];

        for (int i = 0; i < data.size(); i++)
            names[i] = data.get(i).getName();

        list.setListData(names);
        view.setForces(data);
    }

    /**
     * Cuts the force and pastes it where needed
     */
    public void cut() {
        super.cut(list.getSelectedIndices());
    }

    /**
     * Copy the force object to clipboard
     */
    public void copy() {
        super.copy(list.getSelectedIndices());
    }

    /**
     * Get the force element from clipboard and paste
     */
    public void paste() {
        super.paste();
    }

    /**
     * Attach the force
     */
    public void attach() {
        Force force = getInfo();

        if (force != null)
            super.attach(force);
    }

    /**
     * Delete the force
     */
    public void delete() {
        super.delete(list.getSelectedIndex());
    }

    /**
     * edit the force elements
     */
    public void edit() {
        Force force = getInfo(data.get(list.getSelectedIndex()));

        if (force != null)
            super.edit(force, list.getSelectedIndex());
    }

    /**
     * Move the force object down in JList
     */
    public void movedown() {
        super.movedown(list.getSelectedIndex());
    }

    /**
     * Move the force object up in JList
     */
    public void moveup() {
        super.moveup(list.getSelectedIndex());
    }

    //endregion

    //region View Methods

    /**
     * Print the force from the JForceView file
     * @param graphics The Graphics object used for drawing
     * @param pageFormat Page format
     * @param pageIndex Index of the page
     * @return page
     */
    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        if (pageIndex > 0)
            return NO_SUCH_PAGE;

        graphics.translate((int) pageFormat.getImageableX(), (int) pageFormat.getImageableY());

        Dimension old = this.view.getSize();

        this.view.setSize((int) pageFormat.getImageableWidth(), (int) pageFormat.getImageableHeight());

        this.view.zoom();
        this.view.printAll(graphics);

        this.view.setSize(old);
        this.view.zoom();

        return PAGE_EXISTS;
    }

    /**
     * Toggle lock screen
     */
    public void toggleLocked() {
        view.setLocked(!view.isLocked());
    }

    /**
     * Outputs the energy dialog box to the user
     */
    public void energy(){
        if (JOptionPane.showConfirmDialog(null, energy, "Energy", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) {
            JOptionPane.showMessageDialog(null, CalculationUtils.round(getDistance() * CalculationUtils.netForce(data), 2) + "J");
        }
    }

    /**
     * auto Zoom to size
     */
    public void zoom (){
        view.zoom();
    }

    /**
     * Print to printer
     */
    public void print() {
        Book book = new Book();
        book.append(this, job.defaultPage());

        job.setPageable(book);

        if (job.printDialog()) {
            try {
                job.print();
            } catch (PrinterException e1) {
                e1.printStackTrace();
            }
        }
    }

    /**
     * Print preview
     */
    public void preview() {
        job.pageDialog(job.defaultPage());
    }
    /**
     * Save file
     */
    public void saveFile() {
        FileUtils.saveFile(this, "Force File", "frc");
    }

    /**
     * File save as
     */
    public void saveAsFile() {
        FileUtils.saveFile(this, "Force File", "frc");
    }

    /**
     * Open File
     */
    public void openFile() {
        FileUtils.openFile(this, "Force File", "frc");
    }

    /**
     * new File
     */
    public void newFile() {
        FileUtils.newFile(this, "Force File", "frc");
    }

    /**
     * exit method
     */
    public void exit() {
        FileUtils.saveFile(this, "Force File", "frc");
        System.exit(0);
    }

    //endregion

    //region Resultant

    private JPanel resultant;

    private JTable table;

    /**
     * Layout for the resultant menu
     */
    private void layoutResultant() {
        resultant.add(new JScrollPane(this.table));
    }

    /**
     * Styling for the resultant menu
     */
    private void styleResultant() {
        resultant.setBackground(Color.LIGHT_GRAY);

        table.setShowHorizontalLines(false);
        table.setRowMargin(5);
        table.setEnabled(false);
    }

    /**
     * Shows the element for the resultant values
     */
    public void showResultant() {
        Object[][] table = new Object[data.size() + 1][5];
        String[] titles = {"Name", "Magnitude", "Angle", "X-Comp", "Y-Comp"};

        for (int i = 0; i < data.size(); i++) {
            table[i] = new Object[] {
                    data.get(i).getName(),
                    round(data.get(i).getMagnitude(), 2),
                    round(data.get(i).getAngle(), 2),
                    round(getXComponent(data.get(i).getMagnitude(), data.get(i).getAngle()), 2),
                    round(getYComponent(data.get(i).getMagnitude(), data.get(i).getAngle()), 2)
            };
        }

        table[table.length - 1] = new Object[] {
                "Resultant",
                round(netForce(data),2),
                round(netForceAngle(data),2),
                round(netForceX(data),2),
                round(netForceY(data),2)
        };

        this.table.setModel(new DefaultTableModel(table, titles));

        JOptionPane.showMessageDialog(null, resultant, "Resultant", JOptionPane.PLAIN_MESSAGE);
    }

    /**
     * Initializes all the variables
     */
    private void initializeResultant() {
        this.resultant = new JPanel(new BorderLayout());
        this.table = new JTable();
    }

    //endregion
}
