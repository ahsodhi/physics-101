package application.models;

import application.structures.Projectile;

import java.awt.*;
import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by:  Jinesh Patel
 * Date:        2016-01-19
 * File:        ${FILE_NAME}
 * Description:
 */
public class ProjectileModel extends DataModel<Projectile> {
    ProjectileModel(ArrayList<Projectile> data) {
        super(data);
    }

    @Override
    public void read(Scanner in) {

    }

    @Override
    public void write(PrintWriter out) {

    }

    @Override
    protected void update() {

    }

    @Override
    protected Class getDataType() {
        return null;
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        return 0;
    }
}
